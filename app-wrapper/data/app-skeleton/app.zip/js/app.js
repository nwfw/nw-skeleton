var _ = require('lodash');
var path = require('path');
var fs = require('fs');
var BaseClass = require('nw-skeleton').BaseClass;



var _appWrapper;
var appUtil;
var appState;

class App extends BaseClass {

	constructor () {
		super();

		_appWrapper = this.getAppWrapper();
		appUtil = this.getAppUtil();
		appState = this.getAppState();

		appState.mainLoaderTitle = _appWrapper.appTranslations.translate('Please wait, initializing application...');

		return this;
	}

	async initialize () {
		super.initialize();
		if (!window.isDebugWindow){
			setTimeout(() => {
				_appWrapper.windowManager.winState.position = 'center';
				_appWrapper.resetAppStatus();
			}, 400);
		}

		return true;
	}

	async finalize() {
		if (!window.isDebugWindow){
			appState.appInitialized = true;
			return true;
		} else {
			return true;
		}
	}

	async shutdown () {
		if (!window.isDebugWindow){
			appUtil.addUserMessage("Disconnecting databases...", "warning", [], false, false, this.forceUserMessages, this.forceDebug);
			var disconnected = await this.appDb.disconnect();
			if (disconnected){
				appUtil.addUserMessage("Databases disconnected.", "info", [], false, false, this.forceUserMessages, this.forceDebug);
			} else {
				appUtil.addUserMessage("Database disconnecting failed", "error", [], false, false, this.forceUserMessages, this.forceDebug);
			}
			return disconnected;
		} else {
			return true;
		}
	}

	async mockStart (e) {
		e.preventDefault();
		_appWrapper.htmlHelper.updateProgress(0, 100, "Starting");
		await appUtil.wait(2000);
		_appWrapper.htmlHelper.updateProgress(10, 100, "Going");
		await appUtil.wait(1000);
		_appWrapper.htmlHelper.updateProgress(50, 100, "Going");
		await appUtil.wait(2000);
		_appWrapper.htmlHelper.updateProgress(99, 100, "Almost done");
		await appUtil.wait(2000);
		_appWrapper.htmlHelper.clearProgress();
	}
}
exports.App = App;