exports.appState = {
	info: {
		appName: "appname"
	}
}