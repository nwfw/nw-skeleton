var _ = require('lodash');
var _appWrapper = window.getAppWrapper();
var appUtil = _appWrapper.getAppUtil();
var appState = appUtil.getAppState();

exports.component = {
	name: 'app-main',
	template: _appWrapper.templateContents.componentTemplates['app-main'],
	props: ['state'],
	methods: {
		method: function(e){
			console.log(e);
		}
	},
	data: function () {
		return appState.mainData;
	},
	computed: {
		appState: function(){
			return appState;
		}
	},
	components: {}
}